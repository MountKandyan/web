<?php
$version = new JVersion();
jimport('joomla.version');
defined('_JEXEC') or die;
JHtml::addIncludePath(JPATH_COMPONENT . '/helpers');
$params = $this->item->params;
$canEdit	= $this->item->params->get('access-edit');
 $user= JFactory::getUser();
$app	= JFactory::getApplication();
$images  = json_decode($this->item->images);
$urls    = json_decode($this->item->urls);
$info    = $params->get('info_block_position', 0);
$templateparams = $app->getTemplate(true)->params;
?>
<?php if ($this->params->get('show_page_heading', 1)) : ?>
<h1>
<?php echo $this->escape($this->params->get('page_heading')); ?>
</h1>
<?php endif; ?>
<article class="ttr_post<?php echo $this->pageclass_sfx; ?>">
<div class="ttr_post_content_inner">
<?php if ($params->get('show_title')) : ?>
<div class="ttr_post_inner_box">
<h2 class="ttr_post_title">
<?php if ($params->get('link_titles') && !empty($this->item->readmore_link)) : ?>
<a href="<?php echo $this->item->readmore_link; ?>">
<?php echo $this->escape($this->item->title); ?></a>
<?php else : ?>
<?php echo $this->escape($this->item->title); ?>
<?php endif; ?>
</h2>
</div>
<?php endif; ?>
<div class="ttr_article">
<?php if ($canEdit) : ?>
<?php echo JHtml::_('icon.edit', $this->item, $params, array(), true); ?>
<?php endif; ?>
<?php  if (!$params->get('show_intro')) :
echo $this->item->event->afterDisplayTitle;
endif; ?>
<?php echo $this->item->event->beforeDisplayContent; ?>
<?php if($version->RELEASE > 1.7): ?>
<?php if (isset($urls) && ((!empty($urls->urls_position) && ($urls->urls_position == '0')) || ($params->get('urls_position') == '0' && empty($urls->urls_position)))
|| (empty($urls->urls_position) && (!$params->get('urls_position')))) : ?>
<?php echo $this->loadTemplate('links'); ?>
<?php endif; ?>
<?php endif; ?>
<?php if ($params->get('access-view')):?>
<?php if (isset($images->image_fulltext) && !empty($images->image_fulltext)) : ?>
<?php $imgfloat = (empty($images->float_fulltext)) ? $params->get('float_fulltext') : $images->float_fulltext; ?>
<div class="pull-<?php echo htmlspecialchars($imgfloat); ?> item-image"> <img
<?php if ($images->image_fulltext_caption):
echo 'class="caption"'.' title="' .htmlspecialchars($images->image_fulltext_caption) . '"';
endif; ?>
src="<?php echo htmlspecialchars($images->image_fulltext); ?>" alt="<?php echo htmlspecialchars($images->image_fulltext_alt); ?>"/> </div>
<?php endif; ?>
<?php
if (!empty($this->item->pagination) && $this->item->pagination && !$this->item->paginationposition && !$this->item->paginationrelative):
echo $this->item->pagination;
endif;
?>
<?php if (isset ($this->item->toc)) :
echo $this->item->toc;
endif; ?>
<div class="postcontent">
<?php echo $this->item->text; ?>
</div>
<?php
if (!empty($this->item->pagination) AND $this->item->pagination AND $this->item->paginationposition AND!$this->item->paginationrelative):
echo '<div>';
echo $this->item->pagination;
echo '</div>';
endif; ?>
<?php elseif ($params->get('show_noauth') == true AND  $user->get('guest') ) : ?>
<?php echo $this->item->introtext; ?>
<?php if ($params->get('show_readmore') && $this->item->fulltext != null) :
$link1 = JRoute::_('index.php?option=com_users&view=login');
$link = new JURI($link1);?>
<p class="readmore">
<?php if(($templateparams->get('enable_read_more_button')) || ($templateparams->get('enable_read_more_button') == Null)): ?>
<a class="btn btn-default" href="<?php echo $link; ?>">
<?php else:?>
<a href="<?php echo $link; ?>">
<?php endif;?>
<?php $attribs = json_decode($this->item->attribs);  ?>
<?php
if ($attribs->alternative_readmore == null) :
echo JText::_('COM_CONTENT_REGISTER_TO_READ_MORE');
elseif ($readmore = $this->item->alternative_readmore) :
echo $readmore;
if ($params->get('show_readmore_title', 0) != 0) :
echo JHtml::_('string.truncate', ($this->item->title), $params->get('readmore_limit'));
endif;
elseif ($params->get('show_readmore_title', 0) == 0) :
echo JText::sprintf('COM_CONTENT_READ_MORE_TITLE');
else :
echo JText::_('COM_CONTENT_READ_MORE');
echo JHtml::_('string.truncate', ($this->item->title), $params->get('readmore_limit'));
endif; ?></a>
</p>
<?php endif; ?>
<?php endif; ?>
<?php echo $this->item->event->afterDisplayContent; ?>
</div>
</div>
</article>
